/// <reference types="node" />
import Tools from 'clientnode';
import { Encoding, Mapping, PlainObject, Primitive, RecursivePartial } from 'clientnode/type';
import { Options as EJSOptions, TemplateFunction as EJSTemplateFunction } from 'ejs';
import { PluginAPI } from 'web-node';
import { Configuration as BaseConfiguration, Plugin, PluginHandler as BasePluginHandler, Services as BaseServices } from 'web-node/type';
export declare type RenderOptions = EJSOptions & {
    encoding?: Encoding;
    preCompiledTemplateFileExtensions?: Array<string>;
};
export declare type Configuration<ConfigurationType = Mapping<unknown>> = BaseConfiguration<{
    ejs: {
        cache: boolean;
        cacheInPlaceReplacements: boolean;
        extensions: Array<string> | string;
        locations: {
            exclude: Array<string> | string;
            include: Array<string> | string;
            inPlaceReplacements: Array<string> | string;
        };
        options: RenderOptions;
        renderAfterConfigurationUpdates: boolean;
        reloadEntryFiles: boolean;
        reloadSourceContent: boolean;
        scope: {
            evaluation: Mapping;
            execution: Mapping;
            plain: PlainObject<object | Primitive>;
        };
    };
}> & ConfigurationType;
export interface EvaluateScopeValueScope {
    configuration: Configuration;
    currentPath: string;
    fileSystem: typeof import('fs/promises');
    now: Date;
    nowUTCTimestamp: number;
    parser: typeof import('ejs');
    path: typeof import('path');
    PluginAPI: typeof PluginAPI;
    plugins: Array<Plugin>;
    require: typeof require;
    scope: Scope;
    synchronousFileSystem: typeof import('fs');
    template: BasePluginHandler;
    Tools: typeof Tools;
    webNodePath: string;
}
export declare type RenderFunction = (_filePath: string, _nestedLocals?: object) => string;
export declare type Scope = Mapping<unknown> & {
    basePath: string;
    include: RenderFunction;
    options: RenderOptions;
    scope: Scope;
};
export declare type GivenScope = RecursivePartial<Scope>;
export declare type RuntimeScope = Scope & {
    plugins: Array<Plugin>;
};
export declare type Services<ServiceType = Mapping<unknown>> = BaseServices<{
    ejs: {
        getEntryFiles: (_configuration: Configuration, _plugins: Array<Plugin>, _pluginAPI: typeof PluginAPI) => Promise<TemplateFiles>;
        render: (_givenScope: null | GivenScope, _configuration: Configuration, _plugins: Array<Plugin>, _pluginAPI: typeof PluginAPI) => Promise<Scope>;
        renderFactory: (_configuration: Configuration, _scope: GivenScope, _options: RenderOptions) => RenderFunction;
    };
}> & ServiceType;
export declare type TemplateFiles = Set<string>;
export declare type TemplateFunction = EJSTemplateFunction;
export declare type Templates = Mapping<null | TemplateFunction>;
export interface PluginHandler extends BasePluginHandler {
    /**
     * Hook before evaluating a templates. Corresponding files can be modified.
     * @param _entryFiles - Mapping from template file path to compiled
     * function or null.
     * @param _scope - Scope to render again templates.
     * @param _configuration - Configuration object extended by each plugin
     * specific configuration.
     * @param _plugins - Topological sorted list of plugins.
     * @param _pluginAPI - Plugin api reference.
     *
     * @returns Given entry files.
     */
    preEjsRender?(_entryFiles: TemplateFiles, _scope: Scope, _configuration: Configuration, _plugins: Array<Plugin>, _pluginAPI: typeof PluginAPI): Promise<TemplateFiles>;
    /**
     * Hook after rendering templates.
     * @param _scope - Scope to render again templates.
     * @param _entryFiles - Mapping from template file path to compiled
     * function or null.
     * @param _configuration - Configuration object extended by each plugin
     * specific configuration.
     * @param _plugins - Topological sorted list of plugins.
     * @param _pluginAPI - Plugin api reference.
     *
     * @returns Given scope.
     */
    postEjsRender?(_scope: Scope, _entryFiles: TemplateFiles, _configuration: Configuration, _plugins: Array<Plugin>, _pluginAPI: typeof PluginAPI): Promise<Scope>;
}
