import { ChangedConfigurationState, PluginHandler } from 'web-node/type';
import { Configuration, GivenScope, RenderFunction, RenderOptions, Scope, Services, ServicesState, State, TemplateFiles } from './type';
/**
 * Renders all templates again configuration object and re-renders them after
 * configurations changes.
 */
export declare class Template implements PluginHandler {
    /**
     * Triggered hook when at least one plugin has a new configuration file and
     * configuration object has been changed. Asynchronous tasks are allowed
     * and a returning promise will be respected.
     * @param state - Application state.
     *
     * @returns Promise resolving to nothing.
     */
    static postConfigurationHotLoaded(state: ChangedConfigurationState): Promise<void>;
    /**
     * Appends an template renderer to the web node services.
     * @param state - Application state.
     *
     * @returns Promise resolving to nothing.
     */
    static preLoadService(state: ServicesState): Promise<void>;
    /**
     * Triggers when application will be closed soon and removes created files.
     * @param state - Application state.
     * @param state.configuration - Applications configuration.
     * @param state.configuration.ejs - Plugins configuration.
     * @param state.configuration.ejs.locations - Plugins template locations.
     * @param state.services - Applications services.
     *
     * @returns Promise resolving to nothing.
     */
    static shouldExit({ configuration: { ejs: { locations } }, services }: State): Promise<void>;
    /**
     * Retrieves all files to process.
     * @param state - Application state.
     * @param state.configuration - Applications configuration.
     * @param state.plugins - Applications plugins.
     * @param state.pluginAPI - Applications plugin api.
     * @param state.services - Applications services.
     * @param state.services.ejs - Plugins services.
     *
     * @returns A promise holding all resolved files.
     */
    static getEntryFiles({ configuration, plugins, pluginAPI, services: { ejs } }: State): Promise<TemplateFiles>;
    /**
     * Triggers template rendering.
     * @param state - Application state.
     *
     * @returns A promise resolving to nothing.
     */
    static render(state: State): Promise<Scope>;
    /**
     * Generates a render function with given base scope to resolve includes.
     * @param services - An object with stored service instances.
     * @param configuration - Configuration object.
     * @param givenScope - Base scope to extend from.
     * @param givenOptions - Render options to use.
     *
     * @returns Render function.
     */
    static renderFactory(services: Services, configuration: Configuration, givenScope?: GivenScope, givenOptions?: RenderOptions): RenderFunction;
}
export default Template;
