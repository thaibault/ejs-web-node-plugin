import { PluginAPI } from 'web-node';
import { Plugin, PluginHandler } from 'web-node/type';
import { Configuration, GivenScope, RenderFunction, RenderOptions, Scope, TemplateFiles, Templates, Services } from './type';
/**
 * Renders all templates again configuration object and re-renders them after
 * configurations changes.
 * @property static:entryFiles - Mapping from auto determined file paths to
 * there compiled template function.
 * @property static:files - Mapping from determined file paths to there
 * compiled template function.
 */
export declare class Template implements PluginHandler {
    static entryFiles: TemplateFiles;
    static templates: Templates;
    /**
     * Triggered hook when at least one plugin has a new configuration file and
     * configuration object has been changed.
     * @param configuration - Updated configuration object.
     * @param pluginsWithChangedConfiguration - List of plugins which have a
     * changed plugin configuration.
     * @param oldConfiguration - Old configuration object.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns New configuration object to use.
     */
    static postConfigurationLoaded(configuration: Configuration, pluginsWithChangedConfiguration: Array<Plugin>, oldConfiguration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<Configuration>;
    /**
     * Appends an template renderer to the web node services.
     * @param services - An object with stored service instances.
     *
     * @returns Given and extended object of services.
     */
    static preLoadService(services: Omit<Services, 'ejs'>): Services;
    /**
     * Triggers when application will be closed soon and removes created files.
     * @param services - An object with stored service instances.
     * @param configuration - Updated configuration object.
     *
     * @returns Given object of services.
     */
    static shouldExit(services: Services, configuration: Configuration): Promise<Services>;
    /**
     * Retrieves all files to process.
     * @param configuration - Updated configuration object.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns A promise holding all resolved files.
     */
    static getEntryFiles(configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<TemplateFiles>;
    /**
     * Triggers template rendering.
     * @param givenScope - Scope to use for rendering templates.
     * @param configuration - Configuration object.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns A promise resolving to scope used for template rendering.
     */
    static render(givenScope: null | GivenScope, configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<Scope>;
    /**
     * Generates a render function with given base scope to resolve includes.
     * @param configuration - Configuration object.
     * @param givenScope - Base scope to extend from.
     * @param givenOptions - Render options to use.
     *
     * @returns Render function.
     */
    static renderFactory(configuration: Configuration, givenScope?: GivenScope, givenOptions?: RenderOptions): RenderFunction;
}
export default Template;
